/**
 * Desc: Cache List class is the Singly Linked list class that implements
 *        the caching abilities of the different level of caches.
 */
public class CacheList extends LinkedList<ContentItem>{
    private int remainingSize;  // remaining size after ContentItem objects have been added
    private final int maxSize;  // refers to the max size of the cache, currently set at 200

    public CacheList(int size) {
        super();
        this.maxSize = size;
        this.remainingSize = size;
    }

    @Override
    public String toString() {
        StringBuilder temp = new StringBuilder();
        Node<ContentItem> curr = getHead();
        while (curr != null) {
            temp.append("[").append(curr.getData()).append("]\n");
            curr = curr.getNext();
        }
        return String.format("""
                REMAINING SPACE:%d
                ITEMS:%d
                LIST:
                %s""", this.remainingSize, getNumItems(), temp);
    }

    /**
     * Adds a node containing a ContentItem object to the beginning of the list.
     * Uses either the lru/mru eviction policy to remove items from the cache when necessary.
     * @param content - ContentItem object
     * @param evictionPolicy - Either the String "lru" or "mru". Case-insensitive
     * @return null (if successful) or an error message
     */
    public String put(ContentItem content, String evictionPolicy) {
        // YOUR CODE HERE
    }

    /**
     * Searches for the ContentItem object in the cache given the content id.
     * If the item is found, it is then moved to the beginning of the list
     * @param cid - ContentItem id
     * @return ContentItem object or null
     */
    public ContentItem find(int cid) {
        // YOUR CODE HERE
    }

    /**
     * Updates the content of the ContentItem object (if it is found). Node is then moved to the
     * beginning of the list.
     *
     * @param cid - ContentItem id
     * @param content - New ContentItem object for updating the old object
     * @return true if updated, null otherwise
     */
    public Boolean update(int cid, ContentItem content) {
        // YOUR CODE HERE
    }

    /**
     * Removes the first item of the list
     */
    public void mruEvict() {
        // YOUR CODE HERE
    }

    /**
     * Removes the last item of the list
     */
    public void lruEvict() {
        // YOUR CODE HERE
    }

    /**
     * Removes all items from the list
     */
    public void clear(){
        // YOUR CODE HERE
    }
}
