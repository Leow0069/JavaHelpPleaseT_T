/**
 * Desc: Generic Linked List implementation.
 */
public class LinkedList<E> {
    private Node<E> head;
    private int numItems;   // number of Node objects currently in the Linked List

    public LinkedList() {
        this.head = null;
        numItems = 0;
    }

    // ----------------------- Accessor methods ------------------------
    // YOUR CODE HERE
    
    public boolean isEmpty() { return this.numItems == 0; }

    /**
     * Add an item to the head of the linked list
     * @param e item to add
     */
    public void addToHead(E e) {
        // YOUR CODE HERE
    }
    
    /**
     * Remove item from the head of the linked list
     * @return item removed from the head of the linked list
     */
    public E removeFromHead() {
        // YOUR CODE HERE
    }
    
    /**
     * Remove item from the tail of the linked list
     * @return item removed from the tail of the linked list
     */
    public E removeFromTail() {
        // YOUR CODE HERE
    }
}
